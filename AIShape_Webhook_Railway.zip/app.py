
import logging
from flask import Flask, request, jsonify
import telegram
import os
import hashlib
import hmac
import base64
from fpdf import FPDF

# Logging
logging.basicConfig(level=logging.INFO)

# Config
TOKEN = os.getenv("TOKEN") or "8191300003:AAHWifvUYk7KVrkEPTrgLZzrEF2c5Wn0x4g"
SECRET_KEY = os.getenv("WAYFORPAY_SECRET") or "4bc3e98263d8562a095ec2d3e0dbbf97"

bot = telegram.Bot(token=TOKEN)
app = Flask(__name__)

# PDF генерація
def generate_pdf(name):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", 'B', 16)
    pdf.cell(0, 10, f"AIShape: Персональний фітнес-план для {name}", ln=True)
    pdf.set_font("Arial", '', 12)
    pdf.ln(10)
    pdf.multi_cell(0, 10, "🏋️ Тренування на 7 днів:\nПн: Присідання + Віджимання\nВт: Біг + Прес\nСр: Спина + Планка\n...")
    pdf.ln(5)
    pdf.multi_cell(0, 10, "🍽️ Харчування:\nСніданок: Яйця + авокадо\nОбід: Гречка + курка\nВечеря: Риба + овочі\n...")
    file_path = "/tmp/aishape_plan_paid.pdf"
    pdf.output(file_path)
    return file_path

# Перевірка підпису WayforPay
def verify_signature(data, signature, secret_key):
    keys = sorted(data.keys())
    signature_base = ';'.join([str(data[k]) for k in keys])
    dig = hmac.new(secret_key.encode(), msg=signature_base.encode(), digestmod=hashlib.md5).digest()
    encoded = base64.b64encode(dig).decode()
    return signature == encoded

# Вебхук WayforPay
@app.route("/wayforpay_webhook", methods=["POST"])
def wayforpay_webhook():
    payload = request.json
    logging.info(f"Got webhook: {payload}")
    order_reference = payload.get("orderReference", "")
    phone = payload.get("customerPhone", "")
    telegram_id = payload.get("clientEmail", "").replace("telegram_", "")

    signature = payload.get("merchantSignature")
    if not verify_signature(payload, signature, SECRET_KEY):
        return jsonify({"reason": "Invalid signature"}), 403

    if payload.get("transactionStatus") == "Approved":
        try:
            name = "Клієнт"
            file_path = generate_pdf(name)
            with open(file_path, 'rb') as pdf:
                bot.send_document(chat_id=int(telegram_id), document=pdf, filename="AIShape_ProPlan.pdf",
                                  caption="✅ Дякуємо за оплату! Ось ваш персональний план.")
        except Exception as e:
            logging.error(f"Error sending doc: {e}")
            return jsonify({"status": "error"}), 500

    return jsonify({"status": "accept"}), 200

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
